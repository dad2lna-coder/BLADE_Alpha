# Announcement Memo Generator — Visual Resource Pack

This pack contains the generated dashboard reference and reusable visual crops to help recreate its appearance.

## Contents
- `assets/dashboard_reference.png` — complete 1536×1024 visual reference.
- `assets/chaos_brand_header.png` — top branding/header crop.
- `assets/airport_sunset_header.png` — airport sunset banner crop.
- `assets/left_sidebar_art.png` — control-tower/sidebar artwork crop.
- `assets/memo_document_preview.png` — sample memo preview crop.
- `assets/template_document_thumbnail.png` — small document thumbnail crop.
- `design_tokens.css` — starter CSS variables for the visual system.
- `design_spec.md` — layout, color, typography, and component notes.

## Important
The image crops are taken from the generated reference image. They are useful as visual assets/placeholders, but they are not separate original source artwork or editable logo files. Rebuild the interface elements, text, tables, controls, and icons as native HTML/CSS/SVG for a crisp, responsive application.

## Suggested implementation
Use HTML/CSS/JavaScript for the dashboard UI. Keep Python separate as the document-generation engine. The dashboard can later send a structured JSON batch to the portable Python runtime, which generates DOCX and PDF files.
