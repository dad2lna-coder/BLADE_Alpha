# Visual Design Specification

## Overall direction
A desktop-first airport-operations dashboard with a dark navy base, restrained neon-purple and cyan accents, and a cinematic airport header. The visual language should feel operational and technical rather than like a generic office form.

## Canvas and layout
- Reference image: 1536 × 1024 px.
- Top banner: approximately 120 px high.
- Left navigation rail: approximately 190 px wide.
- Main workspace: two-column modular panels with thin colored borders and compact section headers.
- Use rounded corners (roughly 8–12 px), subtle gradients, fine separators, and consistent internal spacing.
- Keep the memo preview large enough to inspect a full page without competing with batch controls.

## Main sections
1. Template Manager: current template, document thumbnail, edit and preview actions.
2. Batch Configuration: spreadsheet-style rows with selection checkboxes, memo names, effective dates, thresholds, and reporting periods.
3. Generation Options: output formats, output folder, filename pattern, cover-page and ZIP options.
4. Preview: paginated memo preview with navigation.
5. Generate Announcements: readiness status and primary generation action.
6. Output Summary: generated file counts, ZIP package, open-folder, view-ZIP, and log actions.

## Color palette (approximate)
- Deep background: `#080F20`
- Panel background: `#101A30`
- Elevated panel: `#17233D`
- Purple accent: `#7138F5`
- Bright purple: `#8B4DFF`
- Cyan accent: `#00BDEB`
- Green success: `#20D65A`
- Amber preview accent: `#F3B51B`
- Primary text: `#F4F6FF`
- Secondary text: `#AAB6D0`
- Divider/border: `#344565`

## Typography
- Use a clean sans-serif such as Segoe UI, Aptos, Inter, or Arial.
- Section titles: semibold/bold.
- Body: regular, compact, high contrast.
- Use tabular numerals for dates, percentages, counts, and status metrics.

## Interaction states to reproduce
- Active navigation item: purple filled/gradient background.
- Selected batch row: clear checkbox and subtle row highlight.
- Primary action: bright purple gradient with visible hover/focus state.
- Success state: green check and concise completion summary.
- Preview panel: amber accent border and scrollable document canvas.

## Implementation note
Treat the reference screenshot as a visual guide, not as a background image for the entire app. Recreate text, controls, tables, icons, and document content as actual UI elements.
